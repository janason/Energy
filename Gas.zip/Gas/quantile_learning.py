import itertools
import math

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import GradientBoostingRegressor
import seaborn as sns
import numpy as np

sns.set_theme(style="white")
Lag = 15
df_dataset = pd.read_excel(io='..\Gas\gas_data.xlsx', sheet_name='data-set')

data_validate = pd.read_excel(io='..\Gas\gas_data.xlsx', sheet_name='validation')

Steps = 8
Gases = ['BFG', 'LDG', 'COG']
alphas = [0.01, 0.05, 0.1]
y_med = []
y_upper = []
y_lower = []
y_picp = []
y_mape = []
y_rmse = []
y_pinaw = []

results = {}

# calculate PICP metric
def PICP(yTest, yLower, yUpper):
    val = 0
    for i in range(len(yTest)):
        if yLower[i] <= yTest[i] <= yUpper[i]:
            val += 1
    return val / len(yTest)


def PINAW(yTest, yLower, yUpper):
    val = 0
    y_min = min(yTest)
    y_max = max(yTest)
    for i in range(len(yTest)):
        val += yUpper[i] - yLower[i]
    return val / (y_max - y_min) / len(yTest)


# calculate MAPE metric
def MAPE(yTest, yMed):
    val = 0
    for i in range(len(yTest)):
        val += abs((yTest[i] - yMed[i]) / yTest[i])
    return val / len(yTest) * 100


def RMSE(yTest, yMed):
    val = 0
    for i in range(len(yTest)):
        val += (yTest[i] - yMed[i]) * (yTest[i] - yMed[i])
    return math.sqrt(val / len(yTest))


def quantify_uncertainty(gas, tau, alpha):
    X_DS = []
    y_DS = []
    T_DS = []
    x = []

    # 1. model training
    for _, row in df_dataset.iterrows():
        t = int(row['period'])
        if t < 0 or t > 1000 - Steps:
            break
        vol = int(row[gas])
        if gas == 'BFG':
            vol = vol / 608
        if gas == 'LDG':
            vol = vol / 75
        if gas == 'COG':
            vol = vol / 59

        if len(x) < Lag:
            x.append(vol)
        else:
            T_DS.append(t)
            volx = df_dataset.iloc[_ + tau][gas]

            if gas == 'BFG':
                volx = volx / 608
            if gas == 'LDG':
                volx = volx / 75
            if gas == 'COG':
                volx = volx / 59

            y_DS.append(volx)
            X_DS.append(x.copy())
            x.pop(0)
            x.append(vol)
    NTrain = int(len(T_DS) * 0.9)
    X_Train = X_DS[0: NTrain]
    X_Test = X_DS[NTrain:]
    y_Train = y_DS[0: NTrain]
    y_Test = y_DS[NTrain:]
    # T_Train = y_DS[0: NTrain]
    # T_Test = y_DS[NTrain:]

    x = []
    X_Vaild = []
    for _, row in data_validate.iterrows():
        t = int(row['period'])
        vol = int(row[gas])
        x.append(vol)
        if len(x) == Lag:
            X_Vaild.append(x.copy())
            x.pop(0)

    common_params = dict(
        learning_rate=0.05,
        n_estimators=100,
        max_depth=2,
        min_samples_leaf=10,
        min_samples_split=10,
    )

    quantiles = [alpha, 0.50, 1 - alpha]
    pred_test = {}
    pred_vaild = {}
    for quantile in quantiles:
        qr = GradientBoostingRegressor(loss="quantile", alpha=quantile, **common_params)
        qrm = qr.fit(np.array(X_Train), np.array(y_Train))
        y_pred = qrm.predict(np.array(X_Test))
        y_vaild = qrm.predict(np.array(X_Vaild))
        pred_test[quantile] = y_pred
        pred_vaild[quantile] = y_vaild[0]

    LB_test = pred_test[quantiles[0]]
    MD_test = pred_test[quantiles[1]]
    UB_test = pred_test[quantiles[2]]

    # calculate MAPE and PICP metric
    y_mape.append(MAPE(y_Test, MD_test))
    y_picp.append(PICP(y_Test, LB_test, UB_test))
    y_rmse.append(RMSE(y_Test, MD_test))
    y_pinaw.append(PINAW(y_Test, LB_test, UB_test))
    y_lower.append(pred_vaild[quantiles[0]])
    y_med.append(pred_vaild[quantiles[1]])
    y_upper.append(pred_vaild[quantiles[2]])

    return y_Test, LB_test, MD_test, UB_test


for gas, alpha in itertools.product(Gases, alphas):
    for tau in range(Steps):
        dt, lb, md, ub = quantify_uncertainty(gas, tau, alpha)
        results[(gas, tau, alpha)] = [dt, lb, md, ub]

    UMAPE = sum(y_mape) / len(y_mape)
    URMSE = sum(y_rmse) / len(y_rmse)
    UPICP = sum(y_picp) / len(y_picp)
    UPINAW = sum(y_pinaw) / len(y_pinaw)
    print(gas, alpha, '=', UMAPE, URMSE, UPICP, UPINAW)
    # print(gas, alpha, '=', y_lower, y_med, y_upper)

    y_med = []
    y_upper = []
    y_lower = []
    y_picp = []
    y_mape = []

sns.set_style("white")

for gas, tau in itertools.product(Gases, range(Steps)):
    y_test = results[gas, tau, 0.05][0]
    y_med = results[gas, tau, 0.05][2]
    y_lb01 = results[gas, tau, 0.01][1]
    y_ub01 = results[gas, tau, 0.01][3]
    y_lb05 = results[gas, tau, 0.05][1]
    y_ub05 = results[gas, tau, 0.05][3]
    y_lb10 = results[gas, tau, 0.10][1]
    y_ub10 = results[gas, tau, 0.10][3]
    x_vals = np.linspace(1, len(y_test), len(y_test))
    print(f'{gas}-{tau}')
    plt.figure(figsize=(10, 5))
    plt.xlabel('Sample No.')
    plt.ylabel('Gas volume')
    plt.fill_between(x_vals, y_lb01, y_ub01, color='gray', alpha=0.35, label='$\\alpha$=0.01')
    plt.fill_between(x_vals, y_lb05, y_ub05, color='gray', alpha=0.25, label='$\\alpha$=0.05')
    plt.fill_between(x_vals, y_lb10, y_ub10, color='gray', alpha=0.15, label='$\\alpha$=0.10')
    plt.scatter(x_vals, y_test, s=30, color='royalblue', label='real value')
    plt.plot(x_vals, y_med,  color='royalblue',  marker='+',  markersize=9, label='median')
    plt.legend(loc='best')
    plt.minorticks_on()
    plt.tick_params(which='major', direction='in')
    plt.show()


# 1. plot violin data
data_violin = []
for _, row in df_dataset.iterrows():
    data_violin.append(['BFG', int(row['BFG']) / 608])
    data_violin.append(['LDG', int(row['LDG']) / 75])
    data_violin.append(['COG', int(row['COG']) / 59])

df_violin = pd.DataFrame(data_violin, columns=['Gas', 'Supply'])
ax = sns.violinplot(x="Gas", y="Supply", inner='box', data=df_violin, kind="violin",
                    height=4, aspect=.7, palette="Set2")
plt.show()

# plot PICP data
fig = plt.figure(figsize=[5, 3])
data_metric = pd.read_excel(io='..\Gas\gas_data.xlsx', sheet_name='result_metric')
data_metric1 = data_metric[(data_metric['alpha'] != 0.50)]
ax = sns.barplot(data=data_metric1, x="gas", hue="alpha", y="metric", palette="Set2")
plt.legend(loc='best')
# ax.set_xlabel('gas')
ax.set_ylabel('PICP')
sns.move_legend(
    ax, "lower center",
    bbox_to_anchor=(.5, 1), ncol=3, title=None, frameon=False,
)
plt.show()

# plot MAPE data
fig = plt.figure(figsize=[4, 2.5])
data_metric2 = data_metric[(data_metric['alpha'] == 0.50)]
ax = sns.barplot(data=data_metric2, x="gas", y="metric", palette="Set2")
# sns.move_legend(
#     ax, "lower center",
#     bbox_to_anchor=(.5, 1), ncol=3, title=None, frameon=False,
# )
# plt.legend(loc='best')
# ax.set_xlabel('gas')
ax.set_ylabel('MAPE(%)')
plt.show()

GAS = ['G1', 'G2', 'G3']
ALPHA = [0.01, 0.05, 0.10]
# plot intervals
data_interval = pd.read_excel(io='..\Gas\gas_data.xlsx', sheet_name='result_interval')
# fig = plt.figure(figsize=[4, 6])
# titles = ['(a) BFG', '(b) LDG', '(C) COG']
i = 1
sns.set_theme(style="white")
for gas in GAS:
    k = 1
    fig = plt.figure(figsize=[6, 3.5])
    for alpha in ALPHA:
        data_fliter = data_interval[(data_interval['gas'] == gas) & (data_interval['alpha'] == alpha)]
        if k == 1:
            plt.step(range(1, Steps + 1), data_fliter['MD'].values, color='royalblue', label='median')

        plt.fill_between(range(1, Steps + 1), data_fliter['LB'].values, data_fliter['UB'].values, step="pre",
                         alpha=0.45 - 0.1 * k, color='gray', label='$\\alpha$=' + str(alpha))

        k = k + 1
    plt.legend(loc='best', fontsize=10)
    plt.xlabel("periods", fontsize=12)
    plt.ylabel("flow ($km^3/h$)", fontsize=12)
    plt.show()
    i = i + 1
plt.show()
