import itertools
import random
import time

import pyomo.environ as pyo
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
import scipy.stats as stats
from pyomo.core import ConcreteModel

from energy_flow import *

T = 8
I = 20
Gamma = 4
alpha = 0.05  # 0.01  0.05  0.10
_Energies = {}
_Entities = {}
_Flows = {}
bigM = 1.0e8
NS = 240


def read_data():
    df_energy = pd.read_excel(io='..\Gas\gas_data.xlsx', sheet_name='energy')
    for _, row in df_energy.iterrows():
        name = row['name']
        en = Energy(name)
        en.omega = row['calorie']
        en.gamma = row['cost']
        _Energies[name] = en

    df_energy = pd.read_excel(io='..\Gas\gas_data.xlsx', sheet_name='storage')
    for _, row in df_energy.iterrows():
        name = row['name']
        store = Storge(name)
        store.energy = _Energies[row['energy']]
        store.min_vol = float(row['min_vol'])
        store.max_vol = float(row['max_vol'])
        store.mid_vol = float(row['mid_vol'])
        store.ini_vol = float(row['init_vol'])
        store.max_dev = float(row['max_dev'])
        _Entities[name] = store

    df_entities = pd.read_excel(io='..\Gas\gas_data.xlsx', sheet_name='conversion', keep_default_na=True)
    for _, row in df_entities.iterrows():
        name = row['entity']
        conv = Conversion(name)
        conv.conv_rho = float(row['efficiency'])
        conv.in_eta = float(row['in_eta'])
        conv.out_eta = float(row['out_eta']) * 0.5
        if isinstance(row['in_limits'], str):
            limit_inputs = row['in_limits'].split(';')
        else:
            limit_inputs = []
        if isinstance(row['out_limits'], str):
            limit_outputs = row['out_limits'].split(';')
        else:
            limit_outputs = []

        for i in range(len(limit_inputs)):
            limit = limit_inputs[i].split(':')
            conv.in_limits[limit[0]] = float(limit[1]) / 4

        for j in range(len(limit_outputs)):
            limit = limit_outputs[j].split(':')
            conv.out_limits[limit[0]] = float(limit[1]) / 4
        _Entities[name] = conv

    # df_entities = pd.read_excel(io='..\Gas\gas_data.xlsx', sheet_name='supply')
    # supply = Supply('supply')
    # sup_names = df_entities.columns.values.tolist()
    # for _, row in df_entities.iterrows():
    #     period = int(row['period'])
    #     for i in range(1, len(sup_names)):
    #         name = sup_names[i]
    #         supply.std_val[name, period] = float(row[sup_names[i]]) / 4.0
    #         supply.pos_dev[name, period] = float(row[sup_names[i]]) / 40.0
    #         supply.neg_dev[name, period] = float(row[sup_names[i]]) / 40.0
    # _Entities['supply'] = supply

    data_interval = pd.read_excel(io='..\Gas\gas_data.xlsx', sheet_name='result_interval')
    supply = Supply('supply')
    for gas in ['G1', 'G2', 'G3']:
        data_fliter = data_interval[(data_interval['gas'] == gas) & (data_interval['alpha'] == alpha)]
        for _, row in data_fliter.iterrows():
            period = int(row['period'])
            supply.std_val[gas, period] = float(row['MD']) / 4.0
            supply.pos_dev[gas, period] = max(float(row['UB']) / 4.0 - supply.std_val[gas, period], 0)
            supply.neg_dev[gas, period] = max(supply.std_val[gas, period] - float(row['LB']) / 4.0, 0)

    _Entities['supply'] = supply

    df_entities = pd.read_excel(io='..\Gas\gas_data.xlsx', sheet_name='demand')
    dmd_names = df_entities.columns.values.tolist()
    demand = Demand('demand')
    for _, row in df_entities.iterrows():
        period = int(row['period'])
        for i in range(1, len(dmd_names)):
            name = dmd_names[i]
            demand.demands[name, period] = float(row[dmd_names[i]]) / 4
    _Entities['demand'] = demand

    df_flow = pd.read_excel(io='..\Gas\gas_data.xlsx', sheet_name='flow')
    for _, row in df_flow.iterrows():
        source = row['source']
        for dest in _Entities.keys():
            en = str(row[dest])
            if en.find('-') > -1:
                continue
            en_list = en.split(',')
            for e in en_list:
                energy = _Energies[e]
                flow = Flow(energy)
                flow.start = _Entities[source]
                flow.end = _Entities[dest]
                name = source + ',' + dest + ',' + e
                _Flows[name] = flow
                _Entities[source].outputs[name] = flow
                _Entities[dest].inputs[name] = flow
    # print(_Entities)
    # print(_Flows)


def build_primal_model():
    # 1. Variables
    all_flows = []
    for _, f in _Flows.items():
        if f.start.type == EntityType.supply and f.end.type == EntityType.storage:
            continue
        all_flows.append(_)

    model = pyo.ConcreteModel("DG2D")
    model.periods = pyo.RangeSet(T)
    model.flows = pyo.Set(initialize=all_flows)
    model.gases = pyo.Set(initialize=['G1', 'G2', 'G3'])
    model.holders = pyo.Set(initialize=[_ for _, entity in _Entities.items() if entity.type == EntityType.storage])
    model.convers = pyo.Set(initialize=[_ for _, entity in _Entities.items() if entity.type == EntityType.conversion])
    model.demands = pyo.Set(initialize=['E', 'S1', 'S2', 'G1', 'G2', 'G3'])

    model.f_var = pyo.Var(model.flows, model.periods, domain=pyo.NonNegativeReals)  # flow
    model.u_var = pyo.Var(model.holders, model.periods, domain=pyo.NonNegativeReals)  # storage
    model.v_var = pyo.Var(model.holders, model.periods, domain=pyo.NonNegativeReals)  # deviation
    model.w_var = pyo.Var(model.demands, model.periods, domain=pyo.NonNegativeReals)  # demand
    model.O_var = pyo.Var(model.convers, model.periods, domain=pyo.Binary)  # on-off
    model.S_var = pyo.Var(model.convers, pyo.RangeSet(T), domain=pyo.Binary)  # start-shut

    # 2. Constraints
    supply = _Entities['supply']
    model.constr = pyo.ConstraintList()
    for h, t in itertools.product(model.holders, model.periods):
        holder: Storge = _Entities[h]
        out_flow = 0
        for _, flow in holder.outputs.items():
            out_flow += model.f_var[_, t]
        in_flow = 0
        for _, flow in holder.inputs.items():
            in_flow = supply.std_val[flow.energy.name, t]
        # constraint (1)
        if t > 1:
            model.constr.add(model.u_var[h, t] - model.u_var[h, t - 1] + out_flow == in_flow)
        else:
            model.constr.add(model.u_var[h, t] + out_flow == in_flow + holder.ini_vol)
        # constraint (2)
        model.constr.add(model.u_var[h, t] >= holder.min_vol)
        model.constr.add(model.u_var[h, t] <= holder.max_vol)
        # constraint (3)
        if t > 1:
            model.constr.add(model.u_var[h, t] - model.u_var[h, t - 1] <= holder.max_dev)
            model.constr.add(model.u_var[h, t - 1] - model.u_var[h, t] <= holder.max_dev)
        else:
            model.constr.add(model.u_var[h, t] - holder.ini_vol <= holder.max_dev)
            model.constr.add(holder.ini_vol - model.u_var[h, t] <= holder.max_dev)
        # constraint (4)
        model.constr.add(model.u_var[h, t] - holder.mid_vol <= model.v_var[h, t])
        model.constr.add(holder.mid_vol - model.u_var[h, t] <= model.v_var[h, t])

    for c, t in itertools.product(model.convers, model.periods):
        conver: Conversion = _Entities[c]
        in_energy = 0
        in_flow = 0
        for _, flow in conver.inputs.items():
            in_energy += model.f_var[_, t] * flow.energy.omega
            in_flow += model.f_var[_, t]
            model.constr.add(
                model.f_var[_, t] <= model.O_var[c, t] * conver.in_limits[flow.energy.name])  # constraint (6)

        out_energy = 0
        out_flow = 0
        for _, flow in conver.outputs.items():
            out_energy += model.f_var[_, t] * flow.energy.omega
            out_flow += model.f_var[_, t]
            model.constr.add(
                model.f_var[_, t] <= model.O_var[c, t] * conver.out_limits[flow.energy.name])  # constraint (7)

        model.constr.add(conver.conv_rho * in_energy == out_energy)  # constraint (5)
        model.constr.add(in_energy >= conver.in_eta * in_flow + bigM * (model.O_var[c, t] - 1))  # constraint (8)
        model.constr.add(
            out_flow >= conver.out_eta * sum(conver.out_limits.values()) + bigM * (
                    model.O_var[c, t] - 1))  # constraint (9)
        model.constr.add(out_flow <= bigM * model.O_var[c, t])  # constraint (10)

        if t > 1:
            model.constr.add(
                model.O_var[c, t] - model.O_var[c, t - 1] <= model.S_var[c, t])  # constraint (11)
            model.constr.add(
                model.O_var[c, t - 1] - model.O_var[c, t] <= model.S_var[c, t])  # constraint (11)

    demand = _Entities['demand']
    for d, t in itertools.product(model.demands, model.periods):
        in_flow = 0
        for _, flow in demand.inputs.items():
            if flow.energy.name == d:
                in_flow += model.f_var[_, t]
        if d in model.gases:
            model.constr.add(in_flow - model.w_var[d, t] >= demand.demands[d, t])  # constraint (12)
        else:
            model.constr.add(in_flow + model.w_var[d, t] >= demand.demands[d, t])  # constraint (12)
    obj_expr1 = 0
    for d in model.demands:
        eng = _Energies[d]
        obj_expr1 += eng.gamma * sum(model.w_var[d, t] for t in model.periods)
    obj_expr2 = 10.0 * sum(model.S_var[c, t] for c, t in itertools.product(model.convers, pyo.RangeSet(T)))
    obj_expr3 = 1.0 * sum(model.v_var[h, t] for h, t in itertools.product(model.holders, model.periods))

    model.obj = pyo.Objective(expr=obj_expr1 + obj_expr2 + obj_expr3, sense=pyo.minimize)
    result = pyo.SolverFactory('gurobi').solve(model)
    print(result)
    if result.solver.status == pyo.SolverStatus.ok:
        print('primal obj = ', model.obj())
        obj_expr1 = 10 * sum(pyo.value(model.S_var[c, t]) for c, t in itertools.product(model.convers, model.periods))
        obj_expr3 = 0
        for d in model.demands:
            eng = _Energies[d]
            obj_expr3 += eng.gamma * sum(pyo.value(model.w_var[d, t]) for t in model.periods)

        obj_expr2 = 1.0 * sum(pyo.value(model.v_var[h, t]) for h, t in
                              itertools.product(model.holders, model.periods))
        print(obj_expr1, obj_expr2, obj_expr3)
        # for _, t in itertools.product(model.demands, model.periods):
        #     print(_, t, ':', model.w_var[_, t].value)
        return model
    else:
        return None


def make_vol_plot(model, robust, s):
    if model is None:
        return
    sns.set_theme(style='white')
    gases = ['BFG', 'LDG', 'COG']
    x_val = np.zeros(T)
    y_val = np.zeros([len(gases), T])
    for t in model.periods:
        x_val[t - 1] = t
        y_val[0, t - 1] = model.u_var['GH-1', t].value
        y_val[1, t - 1] = model.u_var['GH-2', t].value
        y_val[2, t - 1] = model.u_var['GH-3', t].value

    plt.figure(figsize=(6, 4))
    plt.plot(x_val, y_val[0], label="BFG", color='r', linestyle='--', marker='o', markerfacecolor='r',
             markersize=5)
    plt.plot(x_val, y_val[1], label="LDG", color='g', linestyle='--', marker='s', markerfacecolor='g',
             markersize=5)
    plt.plot(x_val, y_val[2], label="COG", color='b', linestyle='--', marker='v', markerfacecolor='b',
             markersize=5)
    plt.xlabel("time period")
    plt.ylabel("volume/$km^3$")
    plt.legend()
    plt.show()

    for t in robust.periods:
        x_val[t - 1] = t
        y_val[0, t - 1] = robust.u_var['GH-1', t, s].value
        y_val[1, t - 1] = robust.u_var['GH-2', t, s].value
        y_val[2, t - 1] = robust.u_var['GH-3', t, s].value

    plt.figure(figsize=(6, 4))
    plt.plot(x_val, y_val[0], label="BFG", color='r', linestyle='--', marker='o', markerfacecolor='r',
             markersize=5)
    plt.plot(x_val, y_val[1], label="LDG", color='g', linestyle='--', marker='s', markerfacecolor='g',
             markersize=5)
    plt.plot(x_val, y_val[2], label="COG", color='b', linestyle='--', marker='v', markerfacecolor='b',
             markersize=5)
    plt.xlabel("time period")
    plt.ylabel("volume/$km^3$")
    plt.legend()
    plt.show()


def random_color(N: int):
    # 随机选择 N 种颜色
    color_list = []
    color_array = ['1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F']
    for k in range(N):
        color = ""
        for i in range(6):
            color += color_array[random.randint(0, 14)]
        color_list.append("#" + color)
    return color_list


def make_flow_plot(optimal, robust, s):
    if optimal is None:
        return
    sns.set_theme(style='white')
    cmap = random_color(len(_Entities))
    y_val = np.zeros(T)
    z1_val = np.zeros([len(_Entities), T])
    # fig = plt.figure(figsize=(15, 6))
    ax1 = plt.axes(projection='3d')

    n = 0
    for c in optimal.convers:
        for t in optimal.periods:
            conver = _Entities[c]
            y_val[t - 1] = t
            for _, flow in conver.inputs.items():
                if optimal.f_var[_, t].value is not None:
                    z1_val[n, t - 1] += optimal.f_var[_, t].value * flow.energy.omega
        ax1.plot3D(np.array([n] * T), y_val, z1_val[n], linewidth=1, marker='o', markersize=3, color=cmap[n])
        n = n + 1
    ax1.set_xticks(np.arange(0, len(optimal.convers), step=1), optimal.convers, rotation=30)
    ax1.set_ylabel('time period')
    ax1.set_zlabel('calorie (kJ) ')
    plt.show()

    ax2 = plt.axes(projection='3d')
    n = 0
    z2_val = np.zeros([len(_Entities), T])
    for c in robust.convers:
        for t in robust.periods:
            conver = _Entities[c]
            y_val[t - 1] = t
            for _, flow in conver.inputs.items():
                if robust.f_var[_, t, s].value is not None:
                    z2_val[n, t - 1] += robust.f_var[_, t, s].value * flow.energy.omega
        ax2.plot3D(np.array([n] * T), y_val, z2_val[n], linewidth=1, marker='o', markersize=3, color=cmap[n])
        n = n + 1
    ax2.set_xticks(np.arange(0, len(optimal.convers), step=1), optimal.convers, rotation=30)
    ax2.set_ylabel('time period')
    ax2.set_zlabel('calorie (kJ)')
    plt.show()


def make_onoff_plot(optimal, robust):
    if optimal is None:
        return
    sns.set_theme(style='white')
    ax1 = plt.axes(projection='3d')
    cmap = random_color(len(_Entities))
    convers = []
    for k, en in _Entities.items():
        if en.type == EntityType.conversion:
            convers.append((k, en))
    x_val = np.linspace(1, len(convers), 1)
    y_val = np.zeros(T)
    z_val = np.zeros([len(convers), T])

    n = 0
    for k, en in convers:
        for t in optimal.periods:
            y_val[t - 1] = t
            z_val[n, t - 1] = optimal.O_var[k, t].value
        ax1.plot3D(np.array([n] * 8), y_val, z_val[n], linewidth=1, marker='o', markersize=3, c=cmap[n])  # 绘制空间曲线
        n = n + 1
    # 显示图
    ax1.set_xticks(np.arange(0, len(convers), step=1.0), [convers[_][0] for _ in range(len(convers))], rotation=30)
    ax1.set_ylabel('time period')
    ax1.set_zlabel('on/off')
    plt.show()

    if robust is None:
        return
    ax2 = plt.axes(projection='3d')
    n = 0
    for k, en in convers:
        for t in robust.periods:
            y_val[t - 1] = t
            z_val[n, t - 1] = robust.O_var[k, t].value
        ax2.plot3D(np.array([n] * 8), y_val, z_val[n], linewidth=1, marker='o', markersize=3, c=cmap[n])  # 绘制空间曲线
        n = n + 1
    # 显示图
    ax2.set_xticks(np.arange(0, len(convers), step=1.0), [convers[_][0] for _ in range(len(convers))], rotation=30)
    ax2.set_ylabel('time period')
    ax2.set_zlabel('on/off')
    plt.show()


def make_dmd_plot(model, robust, s):
    if model is None:
        return
    sns.set_theme(style='white')
    x_val = np.zeros(T)
    w_val = np.zeros([len(model.demands), T])
    colors = random_color(len(_Entities))
    n = 0
    plt.figure(figsize=(6, 4))
    for d in model.demands:
        eng = _Energies[d]
        for t in model.periods:
            x_val[t - 1] = t
            w_val[n][t - 1] = pyo.value(model.w_var[d, t]) * eng.gamma
        plt.plot(x_val, w_val[n], label=d, color=colors[n], marker='o', markerfacecolor=colors[n], markersize=5)
        n = n + 1

    plt.xlabel("time period")
    plt.ylabel("demand deviation (\u00A5)")
    plt.legend()
    plt.show()

    plt.figure(figsize=(6, 4))
    n = 0
    w_val = np.zeros([len(model.demands), T])
    for d in robust.demands:
        eng = _Energies[d]
        for t in robust.periods:
            x_val[t - 1] = t
            w_val[n][t - 1] = pyo.value(robust.w_var[d, t, s]) * eng.gamma
        plt.plot(x_val, w_val[n], label=d, color=colors[n], marker='o', markerfacecolor=colors[n], markersize=5)
        n = n + 1
    plt.xlabel("time period")
    plt.ylabel("demand deviation (\u00A5)")
    plt.legend()
    plt.show()


def make_result_plot():
    sns.set_theme(style="white")
    fig = plt.figure(figsize=(6, 4))
    # 1.budget
    colors = random_color(3)
    df_budget = pd.read_excel(io='..\Gas\gas_data.xlsx', sheet_name='budget')
    df1 = df_budget[(df_budget['alpha'] == 0.01)]
    df5 = df_budget[(df_budget['alpha'] == 0.05)]
    df10 = df_budget[(df_budget['alpha'] == 0.10)]
    # sns.lineplot(data=df1, x="Gamma", y="f", marker="o", markersize=8, dashes=True, label='$\\alpha=0.01$', lw=1.5)
    # sns.lineplot(data=df5, x="Gamma", y="f", marker="v", markersize=9, dashes=True, label='$\\alpha=0.05$', lw=1.5)
    # sns.lineplot(data=df10, x="Gamma", y="f", marker="s", markersize=7, dashes=True, label='$\\alpha=0.10$', lw=1.5)

    plt.plot(df1["Gamma"], df1["f"], marker="s", color='g', markersize=7, label='$\\alpha=0.01$', lw=1.2)
    plt.plot(df5["Gamma"], df5["f"], marker="o", color='r', markersize=7, label='$\\alpha=0.05$', lw=1.2)
    plt.plot(df10["Gamma"], df10["f"], marker="v", color='b', markersize=7, label='$\\alpha=0.10$', lw=1.2)

    plt.xlabel("budget ($\Gamma$)", fontsize=12, labelpad=2)
    plt.ylabel("objective ($10^3$)", fontsize=12, labelpad=2)
    plt.legend()
    plt.show()

    # 2. flexibility
    fig = plt.figure(figsize=(7, 4))
    ax1 = fig.add_subplot(111)
    df_flex = pd.read_excel(io='..\Gas\gas_data.xlsx', sheet_name='flexibility')
    df1 = df_flex[(df_flex['item'] == 'max_dev')]
    df2 = df_flex[(df_flex['item'] == 'min_out')]
    ax1.plot(df1["ratio"], df1["fx"], marker="o", color='r', markersize=7, lw=1.2, label='[$\Delta_{k}$]')
    ax1.set_xlabel("scaling ratio ($\iota$)", fontsize=12, labelpad=2)
    ax1.set_ylabel("objective ($10^3$)", fontsize=12, labelpad=2)
    ax1.legend(loc=6)

    ax2 = ax1.twinx()
    ax2.plot(df2["ratio"], df2["fx"], marker="v", color='b', markersize=7, lw=1.2, label='[$\eta_{k}^-$]')
    ax2.set_ylabel("objective ($10^3$)", fontsize=12, labelpad=2)
    ax2.legend(loc=7)
    plt.show()

    # plt.plot(df2["ratio"], df2["fx"], marker="v", color=colors[1], markersize=8, lw=1.5)
    # plt.xlabel("value of $\eta^{-}_{k}$ ", fontsize=12, labelpad=2)
    # plt.ylabel("objective ($10^3$)", fontsize=12, labelpad=3)
    # plt.show()


def build_RO_model():
    pass


def create_scenarios(ns):
    SE = {}
    for g, t in itertools.product(['G1', 'G2', 'G3'], range(1, T + 1)):
        supply: Supply = _Entities['supply']
        ax = max(supply.std_val[g, t] - supply.neg_dev[g, t], 0)
        bx = supply.std_val[g, t] + supply.pos_dev[g, t]
        avg = supply.std_val[g, t]
        std = (supply.pos_dev[g, t] + supply.neg_dev[g, t]) / 4
        a, b = (ax - avg) / std, (bx - avg) / std
        dist = stats.truncnorm(a, b, loc=avg, scale=std)
        xx = dist.rvs(size=ns)
        for s in range(1, ns + 1):
            SE[g, t, s] = xx[s - 1]
    return SE


def simu_final_model(sce_set, s, on_vars, sw_vars):
    # 1. Variables
    all_flows = []
    for _, f in _Flows.items():
        if f.start.type == EntityType.supply and f.end.type == EntityType.storage:
            continue
        all_flows.append(_)

    model: ConcreteModel = pyo.ConcreteModel("SG2D")
    model.periods = pyo.RangeSet(T)
    model.flows = pyo.Set(initialize=all_flows)
    model.gases = pyo.Set(initialize=['G1', 'G2', 'G3'])
    model.holders = pyo.Set(initialize=[_ for _, entity in _Entities.items() if entity.type == EntityType.storage])
    model.convers = pyo.Set(initialize=[_ for _, entity in _Entities.items() if entity.type == EntityType.conversion])
    model.demands = pyo.Set(initialize=['E', 'S1', 'S2', 'G1', 'G2', 'G3'])

    model.f_var = pyo.Var(model.flows, model.periods, domain=pyo.NonNegativeReals)  # flow
    model.u_var = pyo.Var(model.holders, model.periods, domain=pyo.NonNegativeReals)  # storage
    model.v_var = pyo.Var(model.holders, model.periods, domain=pyo.NonNegativeReals)  # deviation
    model.w_var = pyo.Var(model.demands, model.periods, domain=pyo.NonNegativeReals)  # demand

    # 2. Constraints
    supply = _Entities['supply']
    model.constr = pyo.ConstraintList()
    for h, t in itertools.product(model.holders, model.periods):
        holder: Storge = _Entities[h]
        out_flow = 0
        for _, flow in holder.outputs.items():
            out_flow += model.f_var[_, t]
        in_flow = 0
        for _, flow in holder.inputs.items():
            in_flow = sce_set[flow.energy.name, t, s]
        # constraint (1)
        if t > 1:
            model.constr.add(model.u_var[h, t] - model.u_var[h, t - 1] + out_flow == in_flow)
        else:
            model.constr.add(model.u_var[h, t] + out_flow == in_flow + holder.ini_vol)
        # constraint (2)
        model.constr.add(model.u_var[h, t] >= holder.min_vol)
        model.constr.add(model.u_var[h, t] <= holder.max_vol)
        # constraint (3)
        if t > 1:
            model.constr.add(model.u_var[h, t] - model.u_var[h, t - 1] <= holder.max_dev)
            model.constr.add(model.u_var[h, t - 1] - model.u_var[h, t] <= holder.max_dev)
        else:
            model.constr.add(model.u_var[h, t] - holder.ini_vol <= holder.max_dev)
            model.constr.add(holder.ini_vol - model.u_var[h, t] <= holder.max_dev)
        # constraint (4)
        model.constr.add(model.u_var[h, t] - holder.mid_vol <= model.v_var[h, t])
        model.constr.add(holder.mid_vol - model.u_var[h, t] <= model.v_var[h, t])

    for c, t in itertools.product(model.convers, model.periods):
        conver: Conversion = _Entities[c]
        in_energy = 0
        in_flow = 0
        for _, flow in conver.inputs.items():
            in_energy += model.f_var[_, t] * flow.energy.omega
            in_flow += model.f_var[_, t]
            model.constr.add(
                model.f_var[_, t] <= on_vars[c, t] * conver.in_limits[flow.energy.name])  # constraint (6)

        out_energy = 0
        out_flow = 0
        for _, flow in conver.outputs.items():
            out_energy += model.f_var[_, t] * flow.energy.omega
            out_flow += model.f_var[_, t]
            model.constr.add(
                model.f_var[_, t] <= on_vars[c, t] * conver.out_limits[flow.energy.name])  # constraint (7)

        model.constr.add(conver.conv_rho * in_energy == out_energy)  # constraint (5)
        model.constr.add(in_energy >= conver.in_eta * in_flow + bigM * (on_vars[c, t] - 1))  # constraint (8)
        model.constr.add(
            out_flow >= conver.out_eta * sum(conver.out_limits.values()) + bigM * (
                    on_vars[c, t] - 1))  # constraint (9)
        model.constr.add(out_flow <= bigM * on_vars[c, t])  # constraint (10)

        # if t > 1:
        #     model.constr.add(
        #         model.O_var[c, t] - model.O_var[c, t - 1] <= model.S_var[c, t])  # constraint (11)
        #     model.constr.add(
        #         model.O_var[c, t - 1] - model.O_var[c, t] <= model.S_var[c, t])  # constraint (11)

    demand = _Entities['demand']
    for d, t in itertools.product(model.demands, model.periods):
        in_flow = 0
        for _, flow in demand.inputs.items():
            if flow.energy.name == d:
                in_flow += model.f_var[_, t]
        if d in model.gases:
            model.constr.add(in_flow - model.w_var[d, t] >= demand.demands[d, t])  # constraint (12)
        else:
            model.constr.add(in_flow + model.w_var[d, t] >= demand.demands[d, t])  # constraint (12)

    obj_expr3 = 0
    for d in model.demands:
        eng = _Energies[d]
        obj_expr3 += eng.gamma * sum(model.w_var[d, t] for t in itertools.product(model.periods))
    obj_expr1 = 10.0 * sum(sw_vars[c, t] for c, t in itertools.product(model.convers, pyo.RangeSet(T)))
    obj_expr2 = 1.0 * sum(
        model.v_var[h, t] for h, t in itertools.product(model.holders, model.periods))

    model.obj = pyo.Objective(expr=obj_expr1 + obj_expr2 + obj_expr3, sense=pyo.minimize)
    result = pyo.SolverFactory('gurobi').solve(model)
    if result.solver.status == pyo.SolverStatus.ok:
        f1 = 10 * sum(pyo.value(sw_vars[c, t]) for c, t in itertools.product(model.convers, model.periods))
        f2 = 1.0 * sum(pyo.value(model.v_var[h, t]) for h, t in
                       itertools.product(model.holders, model.periods))
        f3 = 0
        for d in model.demands:
            eng = _Energies[d]
            f3 += eng.gamma * sum(pyo.value(model.w_var[d, t]) for t in model.periods)

        return f1, f2, f3
    else:
        print('---------------')
        return 0, 0, 0


def build_TSSP_model(SE):
    # 1. Variables
    all_flows = []
    for _, f in _Flows.items():
        if f.start.type == EntityType.supply and f.end.type == EntityType.storage:
            continue
        all_flows.append(_)

    model: ConcreteModel = pyo.ConcreteModel("SG2D")
    model.periods = pyo.RangeSet(T)
    model.flows = pyo.Set(initialize=all_flows)
    model.gases = pyo.Set(initialize=['G1', 'G2', 'G3'])
    model.holders = pyo.Set(initialize=[_ for _, entity in _Entities.items() if entity.type == EntityType.storage])
    model.convers = pyo.Set(initialize=[_ for _, entity in _Entities.items() if entity.type == EntityType.conversion])
    model.demands = pyo.Set(initialize=['E', 'S1', 'S2', 'G1', 'G2', 'G3'])
    model.scenarios = pyo.RangeSet(NS)

    model.f_var = pyo.Var(model.flows, model.periods, model.scenarios, domain=pyo.NonNegativeReals)  # flow
    model.u_var = pyo.Var(model.holders, model.periods, model.scenarios, domain=pyo.NonNegativeReals)  # storage
    model.v_var = pyo.Var(model.holders, model.periods, model.scenarios, domain=pyo.NonNegativeReals)  # deviation
    model.w_var = pyo.Var(model.demands, model.periods, model.scenarios, domain=pyo.NonNegativeReals)  # demand
    model.O_var = pyo.Var(model.convers, model.periods, domain=pyo.Binary)  # on-off
    model.S_var = pyo.Var(model.convers, pyo.RangeSet(T), domain=pyo.Binary)  # start-shut

    # 2. Constraints
    supply = _Entities['supply']
    model.constr = pyo.ConstraintList()
    for h, t in itertools.product(model.holders, model.periods):
        for s in model.scenarios:
            holder: Storge = _Entities[h]
            out_flow = 0
            for _, flow in holder.outputs.items():
                out_flow += model.f_var[_, t, s]
            in_flow = 0
            for _, flow in holder.inputs.items():
                in_flow = SE[flow.energy.name, t, s]
            # constraint (1)
            if t > 1:
                model.constr.add(model.u_var[h, t, s] - model.u_var[h, t - 1, s] + out_flow == in_flow)
            else:
                model.constr.add(model.u_var[h, t, s] + out_flow == in_flow + holder.ini_vol)
            # constraint (2)
            model.constr.add(model.u_var[h, t, s] >= holder.min_vol)
            model.constr.add(model.u_var[h, t, s] <= holder.max_vol)
            # constraint (3)
            if t > 1:
                model.constr.add(model.u_var[h, t, s] - model.u_var[h, t - 1, s] <= holder.max_dev)
                model.constr.add(model.u_var[h, t - 1, s] - model.u_var[h, t, s] <= holder.max_dev)
            else:
                model.constr.add(model.u_var[h, t, s] - holder.ini_vol <= holder.max_dev)
                model.constr.add(holder.ini_vol - model.u_var[h, t, s] <= holder.max_dev)
            # constraint (4)
            model.constr.add(model.u_var[h, t, s] - holder.mid_vol <= model.v_var[h, t, s])
            model.constr.add(holder.mid_vol - model.u_var[h, t, s] <= model.v_var[h, t, s])

    for c, t in itertools.product(model.convers, model.periods):
        for s in model.scenarios:
            conver: Conversion = _Entities[c]
            in_energy = 0
            in_flow = 0
            for _, flow in conver.inputs.items():
                in_energy += model.f_var[_, t, s] * flow.energy.omega
                in_flow += model.f_var[_, t, s]
                model.constr.add(
                    model.f_var[_, t, s] <= model.O_var[c, t] * conver.in_limits[flow.energy.name])  # constraint (6)

            out_energy = 0
            out_flow = 0
            for _, flow in conver.outputs.items():
                out_energy += model.f_var[_, t, s] * flow.energy.omega
                out_flow += model.f_var[_, t, s]
                model.constr.add(
                    model.f_var[_, t, s] <= model.O_var[c, t] * conver.out_limits[flow.energy.name])  # constraint (7)

            model.constr.add(conver.conv_rho * in_energy == out_energy)  # constraint (5)
            model.constr.add(in_energy >= conver.in_eta * in_flow + bigM * (model.O_var[c, t] - 1))  # constraint (8)
            model.constr.add(
                out_flow >= conver.out_eta * sum(conver.out_limits.values()) + bigM * (
                        model.O_var[c, t] - 1))  # constraint (9)
            model.constr.add(out_flow <= bigM * model.O_var[c, t])  # constraint (10)

            if t > 1:
                model.constr.add(
                    model.O_var[c, t] - model.O_var[c, t - 1] <= model.S_var[c, t])  # constraint (11)
                model.constr.add(
                    model.O_var[c, t - 1] - model.O_var[c, t] <= model.S_var[c, t])  # constraint (11)

    demand = _Entities['demand']
    for d, t in itertools.product(model.demands, model.periods):
        for s in model.scenarios:
            in_flow = 0
            for _, flow in demand.inputs.items():
                if flow.energy.name == d:
                    in_flow += model.f_var[_, t, s]
            if d in model.gases:
                model.constr.add(in_flow - model.w_var[d, t, s] >= demand.demands[d, t])  # constraint (12)
            else:
                model.constr.add(in_flow + model.w_var[d, t, s] >= demand.demands[d, t])  # constraint (12)
    obj_expr2 = 0
    for d in model.demands:
        eng = _Energies[d]
        obj_expr2 += eng.gamma * sum(model.w_var[d, t, s] for t, s in itertools.product(model.periods, model.scenarios))
    obj_expr1 = 10.0 * sum(model.S_var[c, t] for c, t in itertools.product(model.convers, pyo.RangeSet(T)))
    obj_expr3 = 1.0 * sum(
        model.v_var[h, t, s] for h, t, s in itertools.product(model.holders, model.periods, model.scenarios))

    model.obj = pyo.Objective(expr=obj_expr1 + obj_expr2 / NS + obj_expr3 / NS, sense=pyo.minimize)
    result = pyo.SolverFactory('gurobi').solve(model)
    print(result)
    if result.solver.status == pyo.SolverStatus.ok:
        print('Expected obj = ', model.obj())

        obj_expr1 = 10 * sum(pyo.value(model.S_var[c, t]) for c, t in itertools.product(model.convers, model.periods))
        obj_expr2 = [0 for s in model.scenarios]
        obj_expr3 = [0 for s in model.scenarios]
        for s in model.scenarios:
            obj_expr2[s - 1] = 1.0 * sum(pyo.value(model.v_var[h, t, s]) for h, t in
                                         itertools.product(model.holders, model.periods))
            for d in model.demands:
                eng = _Energies[d]
                obj_expr3[s - 1] += eng.gamma * sum(pyo.value(model.w_var[d, t, s]) for t in model.periods)

        print(obj_expr1, max(obj_expr2), sum(obj_expr2) / len(obj_expr2), max(obj_expr3),
              sum(obj_expr3) / len(obj_expr3))

        return model
    else:
        return None


def build_master_problem(master, i, xi_pos, xi_neg):
    if i == 0:
        # 1. variables of the master problem
        master.periods = pyo.RangeSet(T)
        master.iters = pyo.RangeSet(I)
        master.holders = pyo.Set(initialize=[_ for _, entity in _Entities.items() if entity.type == EntityType.storage])
        master.convers = pyo.Set(
            initialize=[_ for _, entity in _Entities.items() if entity.type == EntityType.conversion])
        master.gases = pyo.Set(initialize=['G1', 'G2', 'G3'])
        master.flows = pyo.Set(
            initialize=[_ for _, f in _Flows.items() if f.start.type != EntityType.supply and
                        f.end.type != EntityType.storage])
        master.flow_names = pyo.Set(initialize=_Flows.keys())
        master.demands = pyo.Set(initialize=['E', 'S1', 'S2', 'G1', 'G2', 'G3'])

        master.O_var = pyo.Var(master.convers, master.periods, domain=pyo.Binary)
        master.S_var = pyo.Var(master.convers, master.periods, domain=pyo.Binary)
        master.beta_var = pyo.Var(domain=pyo.NonNegativeReals)

        master.f_var = pyo.Var(master.flow_names, master.periods, master.iters, domain=pyo.NonNegativeReals)
        master.u_var = pyo.Var(master.holders, master.periods, master.iters, domain=pyo.NonNegativeReals)
        master.v_var = pyo.Var(master.holders, master.periods, master.iters, domain=pyo.NonNegativeReals)
        master.w_var = pyo.Var(master.demands, master.periods, master.iters, domain=pyo.NonNegativeReals)  # demand

        # 2. variables of the constraints
        master.constr = pyo.ConstraintList()
        for c, t in itertools.product(master.convers, master.periods):
            if t > 1:
                master.constr.add(
                    master.O_var[c, t] - master.O_var[c, t - 1] <= master.S_var[c, t])  # constraint (11)
                master.constr.add(
                    master.O_var[c, t - 1] - master.O_var[c, t] <= master.S_var[c, t])  # constraint (11)

        # 3. objective
        obj_expr2 = master.beta_var * 1.0
        obj_expr2 += 10 * sum(master.S_var[c, t] for c, t in itertools.product(master.convers, master.periods))
        master.obj = pyo.Objective(expr=obj_expr2, sense=pyo.minimize)
    else:
        supply = _Entities['supply']
        for h, t in itertools.product(master.holders, master.periods):
            holder: Storge = _Entities[h]
            out_flow = 0
            for f, flow in holder.outputs.items():
                out_flow += master.f_var[f, t, i]
            for f, flow in holder.inputs.items():  # ??? uncertain
                in_flow = supply.std_val[flow.energy.name, t] + xi_pos[h, t] * supply.pos_dev[flow.energy.name, t] \
                          - xi_neg[h, t] * supply.neg_dev[flow.energy.name, t]  # constraint (1)
            if t > 1:
                master.constr.add(master.u_var[h, t, i] - master.u_var[h, t - 1, i] + out_flow == in_flow)
            else:
                master.constr.add(master.u_var[h, t, i] + out_flow == in_flow + holder.ini_vol)
            # constraint (2)
            master.constr.add(master.u_var[h, t, i] >= holder.min_vol)
            master.constr.add(master.u_var[h, t, i] <= holder.max_vol)
            # constraint (3)
            if t > 1:
                master.constr.add(master.u_var[h, t, i] - master.u_var[h, t - 1, i] <= holder.max_dev)
                master.constr.add(master.u_var[h, t - 1, i] - master.u_var[h, t, i] <= holder.max_dev)
            else:
                master.constr.add(master.u_var[h, t, i] - holder.ini_vol <= holder.max_dev)
                master.constr.add(holder.ini_vol - master.u_var[h, t, i] <= holder.max_dev)
            # constraint (4)
            master.constr.add(master.u_var[h, t, i] - holder.mid_vol <= master.v_var[h, t, i])
            master.constr.add(holder.mid_vol - master.u_var[h, t, i] <= master.v_var[h, t, i])

        for c, t in itertools.product(master.convers, master.periods):
            conver: Conversion = _Entities[c]
            out_energy = 0
            out_flow = 0
            for _, flow in conver.outputs.items():
                out_energy += master.f_var[_, t, i] * flow.energy.omega
                out_flow += master.f_var[_, t, i]
                master.constr.add(
                    master.f_var[_, t, i] <= master.O_var[c, t] * conver.out_limits[flow.energy.name])  # constraint (6)
            in_energy = 0
            in_flow = 0
            for _, flow in conver.inputs.items():
                in_energy += master.f_var[_, t, i] * flow.energy.omega
                in_flow += master.f_var[_, t, i]
                master.constr.add(
                    master.f_var[_, t, i] <= master.O_var[c, t] * conver.in_limits[flow.energy.name])  # constraint (7)

            master.constr.add(conver.conv_rho * in_energy == out_energy)  # constraint (5)
            master.constr.add(in_energy >= conver.in_eta * in_flow + bigM * (master.O_var[c, t] - 1))  # constraint (8)
            master.constr.add(out_flow >= conver.out_eta * sum(conver.out_limits.values()) +
                              bigM * (master.O_var[c, t] - 1))  # constraint (9)
            master.constr.add(out_flow <= bigM * master.O_var[c, t])  # constraint (10)

        demand = _Entities['demand']
        for d, t in itertools.product(master.demands, master.periods):
            in_flow = 0
            for _, flow in demand.inputs.items():
                if flow.energy.name == d:
                    in_flow += master.f_var[_, t, i]
            if d in master.gases:
                master.constr.add(in_flow - master.w_var[d, t, i] >= demand.demands[d, t])  # constraint (12)
            else:
                master.constr.add(in_flow + master.w_var[d, t, i] >= demand.demands[d, t])  # constraint (12)

        obj_expr1 = 0
        for d in master.demands:
            eng = _Energies[d]
            obj_expr1 += eng.gamma * sum(master.w_var[d, t, i] for t in master.periods)
        obj_expr3 = 1.0 * sum(master.v_var[h, t, i] for h, t in
                              itertools.product(master.holders, master.periods))
        master.constr.add(master.beta_var >= obj_expr1 + obj_expr3)

    return master


def build_dual_subproblem(O_vars):
    # 1. parameters
    dsp = pyo.ConcreteModel("dsp")
    in_flows = []
    out_flows = []
    all_flows = []
    for _, entity in _Entities.items():
        if entity.type == EntityType.conversion:
            for _, in_flow in entity.inputs.items():
                in_flows.append(_)
            for _, out_flow in entity.outputs.items():
                out_flows.append(_)
    for _, f in _Flows.items():
        if f.start.type == EntityType.supply and f.end.type == EntityType.storage:
            continue
        all_flows.append(_)

    dsp.periods = pyo.RangeSet(T)
    dsp.holders = pyo.Set(initialize=[_ for _, entity in _Entities.items() if entity.type == EntityType.storage])
    dsp.convers = pyo.Set(
        initialize=[_ for _, entity in _Entities.items() if entity.type == EntityType.conversion])
    dsp.gases = pyo.Set(initialize=['G1', 'G2', 'G3'])
    dsp.flows = pyo.Set(initialize=all_flows)
    dsp.in_flows = pyo.Set(initialize=in_flows)
    dsp.out_flows = pyo.Set(initialize=out_flows)
    dsp.demands = pyo.Set(initialize=['E', 'S1', 'S2', 'G1', 'G2', 'G3'])

    # 2. variables
    dsp.lambda1 = pyo.Var(dsp.holders, dsp.periods)  # constraint-1
    dsp.lambda2a = pyo.Var(dsp.holders, dsp.periods, domain=pyo.NonNegativeReals)  # constraint-2a
    dsp.lambda2b = pyo.Var(dsp.holders, dsp.periods, domain=pyo.NonNegativeReals)  # constraint-2b
    dsp.lambda3a = pyo.Var(dsp.holders, dsp.periods, domain=pyo.NonNegativeReals)  # constraint-3a
    dsp.lambda3b = pyo.Var(dsp.holders, dsp.periods, domain=pyo.NonNegativeReals)  # constraint-3b
    dsp.lambda4a = pyo.Var(dsp.holders, dsp.periods, domain=pyo.NonNegativeReals)  # constraint-4a
    dsp.lambda4b = pyo.Var(dsp.holders, dsp.periods, domain=pyo.NonNegativeReals)  # constraint-4b
    dsp.lambda5 = pyo.Var(dsp.convers, dsp.periods)  # constraint-5
    dsp.lambda6 = pyo.Var(dsp.in_flows, dsp.periods, domain=pyo.NonNegativeReals)  # constraint-6
    dsp.lambda7 = pyo.Var(dsp.out_flows, dsp.periods, domain=pyo.NonNegativeReals)  # constraint-7
    dsp.lambda8 = pyo.Var(dsp.convers, dsp.periods, domain=pyo.NonNegativeReals)  # constraint-8
    dsp.lambda9 = pyo.Var(dsp.convers, dsp.periods, domain=pyo.NonNegativeReals)  # constraint-9
    dsp.lambda10 = pyo.Var(dsp.convers, dsp.periods, domain=pyo.NonNegativeReals)  # constraint-10
    dsp.lambda12 = pyo.Var(dsp.demands, dsp.periods, domain=pyo.NonNegativeReals)  # constraint-12

    dsp.xi_pos = pyo.Var(dsp.holders, dsp.periods, domain=pyo.Binary)  # uncertainty-related
    dsp.xi_neg = pyo.Var(dsp.holders, dsp.periods, domain=pyo.Binary)  # uncertainty-related
    dsp.pi_pos = pyo.Var(dsp.holders, dsp.periods)  # uncertainty-related
    dsp.pi_neg = pyo.Var(dsp.holders, dsp.periods)  # uncertainty-related

    # 3. constraint equations
    dsp.uconstr = pyo.ConstraintList()
    dsp.vconstr = pyo.ConstraintList()
    for h, t in itertools.product(dsp.holders, dsp.periods):
        if t < T:
            u_expr = dsp.lambda1[h, t] - dsp.lambda1[h, t + 1] + dsp.lambda2a[h, t] - dsp.lambda2b[h, t] - \
                     dsp.lambda3a[h, t] + dsp.lambda3a[h, t + 1] + dsp.lambda3b[h, t] - dsp.lambda3b[h, t + 1] - \
                     dsp.lambda4a[h, t] + dsp.lambda4b[h, t]
        else:
            u_expr = dsp.lambda1[h, t] + dsp.lambda2a[h, t] - dsp.lambda2b[h, t] - dsp.lambda3a[h, t] + \
                     dsp.lambda3b[h, t] - dsp.lambda4a[h, t] + dsp.lambda4b[h, t]
        dsp.uconstr.add(u_expr <= 0)
        dsp.vconstr.add(dsp.lambda4a[h, t] + dsp.lambda4b[h, t] <= 1.0)

    dsp.fconstr = pyo.ConstraintList()
    for f, t in itertools.product(dsp.flows, dsp.periods):
        flow: Flow = _Flows[f]
        s = flow.start.name
        e = flow.end.name
        g = flow.energy.name
        if flow.start.type == EntityType.storage and flow.end.type == EntityType.demand:  # gas-demand
            f_expr = dsp.lambda1[s, t] + dsp.lambda12[g, t]
        elif flow.start.type == EntityType.storage and flow.end.type == EntityType.conversion:  # input of conversion
            conv: Conversion = flow.end
            f_expr = dsp.lambda1[s, t] + dsp.lambda5[e, t] * conv.conv_rho * flow.energy.omega - dsp.lambda6[f, t] + \
                     (flow.energy.omega - conv.in_eta) * dsp.lambda8[e, t]
        elif flow.start.type == EntityType.supply and flow.end.type == EntityType.conversion:  # input of conversion
            conv: Conversion = flow.end
            f_expr = dsp.lambda5[e, t] * conv.conv_rho * flow.energy.omega - dsp.lambda6[f, t] + \
                     (flow.energy.omega - conv.in_eta) * dsp.lambda8[e, t]
        else:  # output of conversion
            if g in dsp.demands:
                f_expr = - dsp.lambda5[s, t] * flow.energy.omega - dsp.lambda7[f, t] + dsp.lambda9[s, t] - \
                         dsp.lambda10[s, t] + dsp.lambda12[g, t]
            else:
                f_expr = - dsp.lambda5[s, t] * flow.energy.omega - dsp.lambda7[f, t] + dsp.lambda9[s, t] - \
                         dsp.lambda10[s, t]
        dsp.fconstr.add(f_expr <= 0)

    dsp.wconstr = pyo.ConstraintList()
    for d, t in itertools.product(dsp.demands, dsp.periods):
        eng: Energy = _Energies[d]
        if d in dsp.gases:
            dsp.wconstr.add(- dsp.lambda12[d, t] <= eng.gamma)
        else:
            dsp.wconstr.add(dsp.lambda12[d, t] <= eng.gamma)

    dsp.xconstr = pyo.ConstraintList()
    for h in dsp.holders:
        xi_sum = 0
        for t in dsp.periods:
            xi_sum += dsp.xi_pos[h, t] + dsp.xi_neg[h, t]
            dsp.xconstr.add(dsp.pi_pos[h, t] <= bigM * dsp.xi_pos[h, t])
            dsp.xconstr.add(dsp.pi_pos[h, t] <= dsp.lambda1[h, t] + bigM * (1 - dsp.xi_pos[h, t]))
            dsp.xconstr.add(dsp.pi_neg[h, t] <= bigM * dsp.xi_neg[h, t])
            dsp.xconstr.add(dsp.pi_neg[h, t] <= - dsp.lambda1[h, t] + bigM * (1 - dsp.xi_neg[h, t]))
        dsp.xconstr.add(xi_sum <= Gamma)

    # 4. objective functions
    obj_expr = 0
    for h, t in itertools.product(dsp.holders, dsp.periods):
        gas: Energy = _Entities[h].energy
        hold: Storge = _Entities[h]
        supply: Supply = _Entities['supply']
        if t == 1:
            obj_expr += dsp.lambda1[h, t] * (supply.std_val[gas.name, t] + hold.ini_vol)
        else:
            obj_expr += dsp.lambda1[h, t] * (supply.std_val[gas.name, t])

        obj_expr += dsp.pi_pos[h, t] * supply.pos_dev[gas.name, t]
        obj_expr += dsp.pi_neg[h, t] * supply.neg_dev[gas.name, t]

        obj_expr += dsp.lambda2a[h, t] * hold.min_vol
        obj_expr -= dsp.lambda2b[h, t] * hold.max_vol
        if t > 1:
            obj_expr -= dsp.lambda3a[h, t] * hold.max_dev
            obj_expr -= dsp.lambda3b[h, t] * hold.max_dev
        else:
            obj_expr -= dsp.lambda3a[h, t] * (hold.max_dev + hold.ini_vol)
            obj_expr -= dsp.lambda3b[h, t] * (hold.max_dev - hold.ini_vol)
        obj_expr -= dsp.lambda4a[h, t] * hold.mid_vol
        obj_expr += dsp.lambda4b[h, t] * hold.mid_vol
    for f, t in itertools.product(dsp.in_flows, dsp.periods):
        flow = _Flows[f]
        g = flow.energy.name
        e = flow.end.name
        obj_expr -= dsp.lambda6[f, t] * O_vars[e, t] * flow.end.in_limits[g]
    for f, t in itertools.product(dsp.out_flows, dsp.periods):
        flow = _Flows[f]
        g = flow.energy.name
        s = flow.start.name
        obj_expr -= dsp.lambda7[f, t] * O_vars[s, t] * flow.start.out_limits[g]
    for c, t in itertools.product(dsp.convers, dsp.periods):
        conv: Conversion = _Entities[c]
        obj_expr += dsp.lambda8[c, t] * (O_vars[c, t] - 1) * bigM
        obj_expr += dsp.lambda9[c, t] * ((O_vars[c, t] - 1) * bigM + conv.out_eta * sum(conv.out_limits.values()))
        obj_expr -= dsp.lambda10[c, t] * O_vars[c, t] * bigM

    demand = _Entities['demand']
    for d, t in itertools.product(dsp.demands, dsp.periods):
        obj_expr += dsp.lambda12[d, t] * demand.demands[d, t]

    dsp.obj = pyo.Objective(expr=obj_expr, sense=pyo.maximize)

    return dsp


# solving the problem with column-and-constraint-generation
def solve_TSRO_via_CCG():
    LB = 0 - 1.0e8
    UB = 1.0e8
    i = 0
    Z_neg = {}
    Z_pos = {}
    MP = pyo.ConcreteModel("master")
    while UB - LB >= 0.1 and i < I:
        # 1. variables of the master problem
        build_master_problem(MP, i, Z_pos, Z_neg)
        result = pyo.SolverFactory('cplex').solve(MP)
        # print(result)
        if result.solver.status == pyo.SolverStatus.ok:
            LB = MP.obj()  # update LB
            # print('LB = ', LB)
        else:
            print('error..... \n')
            exit()

        O_var = {}
        f2 = 0
        for c, t in itertools.product(MP.convers, MP.periods):
            O_var[c, t] = pyo.value(MP.O_var[c, t])
            f2 += 10 * pyo.value(MP.S_var[c, t])

        SP = build_dual_subproblem(O_var)
        result = pyo.SolverFactory('cplex').solve(SP, options={'IntFeasTol': 1E-9})
        Z_neg.clear()
        Z_pos.clear()
        if result.solver.status == pyo.SolverStatus.ok:
            UB = f2 + SP.obj()  # update UB
            for h, t in itertools.product(SP.holders, SP.periods):
                Z_pos[h, t] = pyo.value(SP.xi_pos[h, t])
                Z_neg[h, t] = pyo.value(SP.xi_neg[h, t].value)
        else:
            print('--------------Error-------------\n')
            exit()
        print('LB=', LB, ' UB=', UB)
        i = i + 1

    # for ii in range(1, i):
    ii = 3
    obj_expr1 = 10 * sum(pyo.value(MP.S_var[c, t]) for c, t in itertools.product(MP.convers, MP.periods))
    obj_expr3 = 0
    for d in MP.demands:
        eng = _Energies[d]
        obj_expr3 += eng.gamma * sum(pyo.value(MP.w_var[d, t, ii]) for t in MP.periods)
    obj_expr2 = 1.0 * sum(pyo.value(MP.v_var[h, t, ii]) for h, t in
                          itertools.product(MP.holders, MP.periods))
    print('robust obj', obj_expr1 + obj_expr2 + obj_expr3)
    print(obj_expr1, obj_expr2, obj_expr3)
    if obj_expr1 + obj_expr2 + obj_expr3 == LB:
        return MP, ii


def multiple_simulation(sce_set, nx, model):
    on_vars = {}
    sw_vars = {}
    convers = [(k, en) for k, en in _Entities.items() if en.type == EntityType.conversion]
    for k, en in convers:
        for t in model.periods:
            on_vars[k, t] = model.O_var[k, t].value
            sw_vars[k, t] = model.S_var[k, t].value
    F1 = []
    F2 = []
    F3 = []
    F = []
    for s in range(1, nx + 1):
        f1, f2, f3 = simu_final_model(sce_set, s, on_vars, sw_vars)
        F1.append(f1)
        F2.append(f2)
        F3.append(f3)
        F.append(f1 + f2 + f3)
    print(max(F1), sum(F1) / nx, max(F2), sum(F2) / nx, max(F3), sum(F3) / nx, max(F), sum(F) / nx)


def main():
    read_data()
    t1 = time.perf_counter()
    SE = create_scenarios(NS)
    TSSP = build_TSSP_model(SE)
    t2 = time.perf_counter()
    print(t2 - t1)
    robust, s = solve_TSRO_via_CCG()
    # t3 = time.perf_counter()
    # print(t3 - t2)
    #
    # SEX = create_scenarios(800)
    # print('robust simulation:')
    # multiple_simulation(SEX, 800, robust)
    # print('stochastic simulation:')
    # multiple_simulation(SEX, 800, TSSP)
    # simulate
    #
    # for k, en in convers:
    #     for t in TSSP.periods:
    #         on_vars[k, t] = TSSP.O_var[k, t].value
    #         sw_vars[k, t] = TSSP.S_var[k, t].value
    # F1 = []
    # F2 = []
    # F3 = []
    # F = []
    # for s in range(1, NS + 1):
    #     f1, f2, f3 = simu_final_model(SEX, s, on_vars, sw_vars)
    #     F1.append(f1)
    #     F2.append(f2)
    #     F3.append(f3)
    #     F.append(f1 + f2 + f3)
    # print(max(F1), sum(F1)/800, max(F2), sum(F2)/800, max(F3), sum(F3)/800, max(F), sum(F)/800)

    # make_result_plot()

    optimal = build_primal_model()
    # t4 = time.perf_counter()
    # print(t4 - t3)
    #
    # make_onoff_plot(optimal, robust)
    # make_flow_plot(optimal, robust, s)
    # make_vol_plot(optimal, robust, s)
    make_dmd_plot(optimal, robust, s)

    print("main exit.....")


if __name__ == "__main__":
    main()
