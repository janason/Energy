from enum import Enum


class EntityType(Enum):
    supply = 0
    storage = 1
    conversion = 2
    demand = 3


class Energy(object):
    def __init__(self, name):
        self.name = name
        self.omega = 0.0  # calorie
        self.gamma = 0.0  # cost coefficients


class Entity(object):

    def __init__(self, name, type):
        self.name = name
        self.type = type
        self.inputs = {}  # name, Flow
        self.outputs = {}  # name, Flow


class Supply(Entity):
    def __init__(self, name):
        super().__init__(name, EntityType.supply)
        self.std_val = {}
        self.pos_dev = {}
        self.neg_dev = {}


class Storge(Entity):
    def __init__(self, name):
        super().__init__(name, EntityType.storage)
        self.min_vol = 0.0
        self.max_vol = 0.0
        self.mid_vol = 0.0
        self.ini_vol = 0.0
        self.max_dev = 0.0
        self.energy = None


class Conversion(Entity):
    def __init__(self, name):
        super().__init__(name, EntityType.conversion)
        self.in_limits = {}
        self.out_limits = {}
        self.conv_rho = 0.0
        self.in_eta = 0.0
        self.out_eta = 0.0
        self.is_running = {}


class Demand(Entity):
    def __init__(self, name):
        super().__init__(name, EntityType.demand)
        self.demands = {}
        self.diffs = {}


class Flow(object):
    def __init__(self, energy):
        self.start: Entity = None
        self.end: Entity = None

        self.fixed = False
        self.energy = energy
        self.flow = {}
